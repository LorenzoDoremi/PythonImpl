from random import random

# 0 = en
# 1 = it
dataset = [
    ("cat", 0),
    ("dog", 0),
    ("gatto", 1),
    ("fazzoletto", 1),
    ("falce", 1),
    ("elemosina", 1),
    ("elephant", 0),
    ("king", 0),
    ("reticence", 0),
    ("guerriero", 1),
    ("detrazione", 1),
    ("warrior", 0),
    ("cloud", 0),
    ("berserk", 0),
    ("vendetta", 1),
    ("fiscalita", 1),
    ("isola", 1),
    ("ratti", 1),
    ("milanese", 1),
    ("innocence", 0),
    ("limit", 0),
    ("brought", 0),
    ("demon", 0),
    ("cat", 0),
    ("dog", 0),
    ("gatto", 1),
    ("fazzoletto", 1),
    ("falce", 1),
    ("elemosina", 1),
    ("elephant", 0),
    ("king", 0),
    ("reticence", 0),
    ("guerriero", 1),
    ("detrazione", 1),
    ("warrior", 0),
    ("cloud", 0),
    ("berserk", 0),
    ("vendetta", 1),
    ("fiscalita", 1),
    ("isola", 1),
    ("ratti", 1),
    ("milanese", 1),
    ("innocence", 0),
    ("limit", 0),
    ("brought", 0),
    ("demon", 0),
    ("gatto", 1),
    ("fazzoletto", 1),
    ("falce", 1),
    ("elemosina", 1),
    ("elephant", 0),
    ("king", 0),
    ("reticence", 0),
    ("guerriero", 1),
    ("detrazione", 1),
    ("warrior", 0),
    ("cloud", 0),
    ("berserk", 0),
    ("vendetta", 1),
    ("fiscalita", 1),
    ("isola", 1),
    ("ratti", 1),
    ("milanese", 1),
    ("innocence", 0),
    ("limit", 0),
    ("brought", 0),
    ("demon", 0),

]


smalldataset = [("warrior", 0), ("guerriero", 1)]

# 97


# 15
class nodo:
    def __init__(self):
        self.sinapsi_in = []
        self.sinapsi_out = []
        self.v = 0


class sinapsi:
    def __init__(self, n1, n2):
        self.w = random()
        self.before: nodo = n1
        self.after: nodo = n2
        self.active = False

    def send(self, activated):
        if self.before.v >= 0.35:
            self.after.v += (1*self.w)/(activated)
            self.active = True


first_col = [nodo() for x in range(25*15)]
second_col = [nodo() for x in range(10)]
last_col = [nodo() for x in range(2)]


# tengo in memoria tutte le sinapsi per il refresh/correzione
sinapsi_list = []

for nodo1 in first_col:
    for nodo2 in second_col:
        temp_sin = sinapsi(nodo1, nodo2)
        nodo1.sinapsi_out.append(temp_sin)
        sinapsi_list.append(temp_sin)


for nodo2 in second_col:
    for nodofin in last_col:
        temp_sin = sinapsi(nodo2, nodofin)
        nodo2.sinapsi_out.append(temp_sin)
        nodofin.sinapsi_in.append(temp_sin)
        sinapsi_list.append(temp_sin)




def refresh(correct, sinapsi_list):
  # aggiusto i pesi delle sinapsi
    for sinapsi in sinapsi_list:
        if sinapsi.active:
            if correct:
                sinapsi.w += 0.01
            else:
                sinapsi.w -= 0.01
        else:
            if correct:
               sinapsi.w -= 0.01
            else:
               sinapsi.w += 0.01
        if sinapsi.w > 1:
            sinapsi.w = 1
        if sinapsi.w < 0:
            sinapsi.w = 0

        sinapsi.active = False
        sinapsi.before.v = 0
        sinapsi.after.v = 0



def send_input(data, first_col, second_col, last_col):
    
 # accendo i nodi input
 for index, l in enumerate(data["data"]):

    curr_i = 15*(ord(l) - 97) -15
    
    first_col[curr_i].v = 1
    for sinapsi in first_col[curr_i].sinapsi_out:
            sinapsi.send(len(data["data"]))


 # calcolo quanti sono accesi per la media
 activated = 0
 for nodo in second_col:
    if nodo.v > 0.35:
        activated += 1
 # attivo i nodi fino a quello finale
 for nodo in second_col:
    if nodo.v > 0.35:
        for sinapsi in nodo.sinapsi_out:
            sinapsi.send(activated)
 max = 0
 i = 0
 # trovo la soluzione
 for index, nodo in enumerate(last_col):
    if nodo.v > max:
        max = nodo.v
        i = index
 return i == data["value"]



precision = 0
iterations = 1000


myset = smalldataset

for i in range(iterations):
 
 test = {"data": myset[int(random()*len(myset))][0], "value": myset[int(random()*len(myset))][1]}
 
 solution = send_input(test, first_col, second_col, last_col)
 refresh(solution, sinapsi_list)
 if solution:
        precision+=1
        

print("--------------- \n \n \n ")

''' for nodo in last_col:
    for sin in nodo.sinapsi_in:
        print(sin.w) '''

print(precision/iterations)
