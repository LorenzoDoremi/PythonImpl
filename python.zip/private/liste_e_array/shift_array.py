array = [x for x in range(0,10)]
# T = O(N), S = O(N)
def shift_array(array, k):
    t = []
    
    for i in range(0, len(array)):
      t.append(array[(i+k)%len(array)])
    return t

t = shift_array(array, -1)
print(t)

# T = O(N*K), S = O(1) ??