array = [x for x in range(0,10)]

# T = O(N), S = O(1)
def invert_array(array):
 for i in range(0, int(len(array)/2)):
    array[i], array[len(array)-(i+1)] = array[len(array)-(i+1)], array[i]
 return array

print(invert_array(array))
print(invert_array(array))



