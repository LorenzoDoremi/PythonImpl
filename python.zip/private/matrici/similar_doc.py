import numpy



# questo codice qua sotto è l'implementazione di strings[n].split(" ") e poi aggiunge la parola a words
def create_vocabulary(strings):

    words = []
    for i in range(0, len(strings)):

        j = 0
        curr_word = ""
        while(j <= len(strings[i])):
            if j == len(strings[i]) or strings[i][j] == " ":
                j += 1
                if not words.__contains__(curr_word):
                    words.append(curr_word)
                curr_word = ""
            else:
                curr_word += strings[i][j]
                j += 1

    return words




# questo metodo, dato un vocabolario words ed N stringhe (o documenti!) in un array strings, 
# ritorna dei dizionari contenenti le stringhe e il rispettivo array di presenze. (1 se la contiene, 0 no)
def string_vectors(strings, words):
    string_vectors = []
    for i in range(0, len(strings)):

        i_vector = []
        for word in words:

            if strings[i].__contains__(word):
                i_vector.append(1)
            else:
                i_vector.append(0)

        string_vectors.append({"stringa": strings[i], "vector": i_vector})
    return string_vectors
    

    

# chiamabile su vettori di pari lunghezza N. 
# calcola la distanza cartesiana tra due vettori a N dimensioni.
def vector_distance(a1,a2):

    distance = 0
    for i in range(0,len(a1)):
        distance += (a1[i]-a2[i])**2
    
    return numpy.sqrt(distance)

# ritorna una matrice di distanze vettoriali    
def distance_matrix(docs): 
    ""
    matrix = numpy.zeros((len(docs), len(docs)))
    for i in range(0,len(docs)):
        for j in range(0,len(docs)):

            matrix[i][j] = vector_distance(docs[i]["vector"], docs[j]["vector"])
    return matrix


#ritorna il documento più simile di una matrice di similarità 
def find_similar_doc(docs, id): 

    min = numpy.Infinity
    
    for i in range(0,len(docs[id])):
        if docs[id][i] < min and docs[id][i] > 0:
            min =  docs[id][i]
    return min

#crea l'indice inverso dato un vocabolario e le parole. 
def inverted_index(vocabulary, docs):

    inverted_index = []
    for i in range(0,len(vocabulary)):
      inverted_index.append({"word": vocabulary[i], "occs":0, "pointers":[]})
      for j in range(0,len(docs)):
            
            
            if docs[j].__contains__(vocabulary[i]):
               
                inverted_index[i]["occs"] += 1
                inverted_index[i]["pointers"].append(j)
    return inverted_index







strings = [
    "nel mezzo del cammin di nostra mezzo cammin di nostra vita mi ritrovati per una selva oscura",
    "nel mezzo del cammin di nostra vita",
    "Dormi sepolto in un campo di grano non è la rosa non è il tulipano",
    "bel pezzo del camino di rostra dita mi ritrombati er una belva ascira",
    "Lucci argentati e non più cadaveri dei soldati portati in braccio dalla corrente",
    "nel mezzo del camino di vostra dita, non è la rosa non è il braccio dalla corrente "
]

vocabulary = create_vocabulary(strings)
#vocabolario
docs = string_vectors(strings, vocabulary)
#distance
distances = distance_matrix(docs)   


string_1 = find_similar_doc(distances, 0)


index = inverted_index(vocabulary, strings )

for vector in index:
    print(vector["word"] + " "+str(vector["occs"]), end=" ")
    print(vector["pointers"])

      




    


# questo metodo ritorna la differenza/somiglianza tra due stringhe, in base alle lettere. non semanticamente interessante!
def string_distance_letters(s, s1):

    maxlen = max(len(s), len(s1))
    base = 0
    for i in range(0, maxlen):

        if i >= len(s) or i >= len(s1):
            base += 1

        elif s[i] == s1[i]:
            base += 0
        else:
            base += 1
    return base

# ritorna la matrice delle differenze/somiglianze che calcola la distanza tra tutte le stringhe contenute in un array
def string_similarities_matrix(strings):

    matrix = numpy.zeros((len(strings), len(strings)))
    for i in range(0, len(matrix)):
        for j in range(0, len(matrix[i])):
            matrix[i][j] = string_distance_letters(strings[i], strings[j])
    return matrix


similarities = string_similarities_matrix(strings)
# print(similarities)
