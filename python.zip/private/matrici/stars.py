from random import random
import numpy
import test.pygioco as pygioco

# crea luci con un fattore di decadimento esponenziale


def illuminate_exp(matrix, x, y, power, decay):

    if x >= 0 and x < len(matrix) and y >= 0 and y < len(matrix[x]):

        newv = matrix[x][y] + power
        matrix[x][y] = min(255, newv)

        if power > 1:
            illuminate_exp(matrix, x+1, y, int(power/decay), decay)
            illuminate_exp(matrix, x-1, y, int(power/decay), decay)
            illuminate_exp(matrix, x, y+1, int(power/decay), decay)
            illuminate_exp(matrix, x, y-1, int(power/decay), decay)


# crea luci con un fattore di decadimento lineare
def illuminate_sub(matrix, x, y, power, decay):

    if x >= 0 and x < len(matrix) and y >= 0 and y < len(matrix[x]):

        if power > 1 and matrix[x][y] < power:
            
            matrix[x][y] = min(255, matrix[x][y]+power)
            illuminate_sub(matrix, x+1, y, int(power - decay), decay)
            illuminate_sub(matrix, x-1, y, int(power - decay), decay)
            illuminate_sub(matrix, x, y+1, int(power - decay), decay)
            illuminate_sub(matrix, x, y-1, int(power - decay), decay)


matrix = numpy.zeros((800, 800))

for i in range(0, 25):

    x = int(random()*len(matrix))
    y = int(random()*len(matrix))
    illuminate_sub(matrix, x, y, 255, 1)


pygioco.init()
pygioco.display.set_caption('Stars')
canvas = pygioco.display.set_mode((len(matrix), len(matrix)))


for x in range(0, len(matrix)):
    for y in range(0, len(matrix)):

        canvas.set_at((x, y), [matrix[x][y], matrix[x][y], matrix[x][y]])


while True:  # main game loop

    for event in pygioco.event.get():
        ""
    pygioco.display.update()
