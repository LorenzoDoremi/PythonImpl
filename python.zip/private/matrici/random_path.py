from random import random
import numpy


map = numpy.zeros((8,8))



nums =8



def random_path(map, nums):
    
    start = (0,0)
    end = (int(random()*len(map)-1), int(random()*len(map)-1))
   

    #genero una serie di tuple 2D randomiche all'interno della matrice   
    p = [start]
    for i in range(0,nums):
        p.append((int(random()*len(map)), int(random()*len(map))))
    p.append(end)
    print(p)
    for i in range(0,len(p)-1):

        #x e y della tupla corrente
        x = p[i][0]
        y = p[i][1]
        # vado a sinistra
        # p[i+1] = x del numero successivo
        if x < p[i+1][0]:
         while x < p[i+1][0]:
            map[p[i][1]][x] = 1
            x+=1
            
        else:
        # vado a destra
         while x > p[i+1][0]:
            map[p[i][1]][x] = 1
            x-=1
         # vado giu
        if y < p[i+1][1]:
          while y < p[i+1][1]:
            map[y][x] = 1
            y +=1
        else:
           # vado a su  
          while y > p[i+1][1]:
                map[y][x] = 1
                y -=1
        
        map[end[1]][end[0]] =  2
                

          
      
        
        
random_path(map, nums)

print(map) 