from random import random



def fib(x):

    if x == 0: 
        return 0
    if x == 1:
        return 1
    else:
        return fib(x-1) + fib(x-2)


# dato un array, un indice di partenza (la prima casella) e n interazioni, si scriva una funzione ricorsiva che ritorni vero se 
# trova uno zero saltando nell'array, o falso se le iterazioni terminano.
# un SALTO è definito come l'andare avanti di k caselle da quella attuale, dove k è il valore della casella attuale. 
# ad esempio se all'inizio trovo il valore 5 nella casella 3, al passo successivo andrò alla 8.
def jumper(array, i, iterations):
   
   if iterations == 0:
         return False
   if array[i] == 0:
      return True
   else:
      return jumper(array, (i + array[i])%len(array), iterations-1)


j = [int(random()*10) for x in range(0,10)]

x = jumper(j,0,10)
print(x)

print(fib(8))


def find_mind(tree):
    if tree.left:
        return find_mind(tree.left)
    else:
         return tree    