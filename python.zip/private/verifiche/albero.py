import random
import matplotlib.pyplot as plt
'''
al fine di installare una rete di carattere gerarchico, si è  deciso di utilizzare una topologia ad albero
quest'albero, per questioni di semplicità implementativa, è pensato come un albero binario: 
ogni dispositivo ha un id/ip/mac, e due figli: uno sinistro e uno destro. Il figlio sinistro ha sempre un id minore
mentre quello destro maggiore o uguale. 
al fine di completare la definizione di un oggetto device, vengono richieste le seguenti implementazioni: 

1: si scriva un programma che appende N nuovi dispositivi di id variabile. (2p)

2: si scriva una funzione ricorsiva che stampa i dispositivi in ordine inverso (postorder) (2p)

3: si scriva una funzione che calcola la distanza tra il device radice e un device di chiave k (2p)

4: si scriva una funzione o un programma che per ogni device id compreso tra 0 e 100 rappresenta graficamente la distanza Y dalla radice (2)

5: si scriva una funzione o un programma che rappresenta in un grafico il rapporto tra la distanza (Y) di un device random dalla radice
e la dimensione della rete (X) in cui è cercato (3p) 

6: si scriva una funzione o programma che determina la distanza tra due nodi k1 e k2 nella rete. 
aiuto: salva gli id dei nodi nel percorso dalla radice a ciascun nodo separatamente, poi determina l'ultimo nodo comune! (3p)

6: considerazioni aggiunte (si nota qualcosa dai grafici?)

7: (VERY HARD) si scriva una funzione o programma che determina la distanza tra due nodi k1 e k2 nella rete. 
aiuto:
- salva gli id dei nodi nel percorso dalla radice a ciascun nodo separatamente
- poi determina l'id comune più a destra nei percorsi
- somma le distanze dalla fine dei due array rispetto a questo id

punti massimi = 16. ogni punto corrisponde ad un voto
'''

class Device():
    def __init__(self, k) -> None:
        self.k = k 
        self.left = None
        self.right = None
    # aggiungo un nuovo device alla rete 
    def appendR(self, k):
        if k < self.k:
            if self.left: 
                self.left.appendR(k)
            else:
                self.left = Device(k)
        else:
            if self.right:
                self.right.appendR(k)
            else: 
                self.right = Device(k)
                
    # questa funzione permette di stampare in ordine i dispositivi dall'id minore al maggiore
    def inorder(self):
        if self.left:
            self.left.inorder()
        print(self.k)
        if self.right: 
            self.right.inorder()
            
    # 2: postorder
    def postorder(self):
        if self.right: 
            self.right.postorder()
        print(self.k)
        if self.left:
            self.left.postorder()
        
        
        
    # 3: distanza 
    def distance(self,k,d):
        if(self.k == k):
            return d
        else:
            if(k < self.k and self.left):
               return self.left.distance(k,d+1)
            elif( self.right):
               return self.right.distance(k,d+1)
        return -1 
    ''' 
    def path(self,lista, k):
        
        lista.append(self.k)
        if(self.k == k):
            return True
        else:
            if(k < self.k and self.left):
               return self.left.path(lista,k)
            elif( self.right):
               return self.right.path(lista,k)
    
    # esercizio 7 
    def distance_2(self,k,k2):
        p1 = []
        p2 = []
        self.path(p1,k)
        self.path(p2,k2)
        print(p1)
        print(p2)
        k = -1
        if(len(p1) < len(p2)):
            for i in range(len(p1)-1, -1, -1):
                
                if(p1[i] in p2):
                    k = p1[i]
                    break
        else: 
            for i in range(len(p2)-1, -1, -1):
                if(p2[i] in p1):
                    k = p2[i]
                    break 
       
        # cerco il nodo k in p1 
        d = 0 
        d2 = 0
        for i in range(0,len(p1)):
            if p1[i] == k:
                d+=1
                break
            d+=1
        for i in range(0,len(p2)):
            if(p2[i] == k):
                d2+=1
                break 
            d2+=1
        print("k = ",k," d= ",d, " d2 =  ", d2)
        print("-------------------------------")
        return (len(p1)-d) + (len(p2)-d2)
    '''       
        
    


x = []
y = []

# esercizio 1 
albero_test = Device(int(random.uniform(1,100)))
for j in range(0,20):
        r = int(random.uniform(10,40))
        albero_test.appendR(r)
        
albero_test.appendR(20)
albero_test.appendR(30)

albero_test.postorder()
print("-----------")
print(albero_test.distance(20,0))

'''
# esercizio 4 
x = [i for i in range(0,1000)]
y = []
for i in x: 
    y.append(albero_test.distance(i,0))
#plt.plot(x,y)
    
# es5 
# genero 10 alberi di test
x = []
y = []
for i in range(1,10):
    # ogni albero avrà dimensione n 
    x.append(i*1000)
    albero = Device(int(random.uniform(0,200)))
    # appendo i*100 nodi
    for n in range(1,i*1000):
        
        albero.appendR(int(random.uniform(0,200)))
    # cerco un nodo random 
    chiave = int(random.uniform(0,200))
    distanza = albero.distance(chiave,0)
    y.append(distanza)

plt.plot(x,y)
plt.show()

 
 

for i in range(0,s):
    t = root.distance(i,0)
    if t >= 0:
        x.append(i)
        y.append(t)
'''    


