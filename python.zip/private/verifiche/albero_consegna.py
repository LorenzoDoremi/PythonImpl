import random
import matplotlib.pyplot as plt
'''
al fine di installare una rete di carattere gerarchico, si è  deciso di utilizzare una topologia ad albero.
quest'albero, per questioni di semplicità implementativa, è pensato come un albero binario: 
ogni dispositivo ha un id/ip/mac, e due figli: uno sinistro e uno destro. Il figlio sinistro ha sempre un id minore
mentre quello destro maggiore o uguale. 
al fine di completare la definizione di un oggetto device, vengono richieste le seguenti implementazioni: 

1: si scriva un programma che inserisce nella rete N nuovi dispositivi di id random. (2p)

2: si scriva una funzione ricorsiva che stampa i dispositivi dall'id maggiore al minore (postorder) (2p)

3: si scriva una funzione che calcola la distanza tra il device radice e un device di id k (2p)

4: si scriva una funzione o un programma che per ogni device id compreso tra 0 e N ( a scelta) 
   rappresenta graficamente la distanza Y del dispositivo dalla radice (2)

5: si scriva una funzione o un programma che rappresenta in un grafico il rapporto tra la distanza (Y) di un device random dalla radice
e le dimensioni delle reti (X) in cui è cercato (3p). ad esempio reti di 10,100,1000 nodi... 

6: considerazioni aggiunte (si nota qualcosa dai grafici?) (0.5p)

7: (VERY HARD) si scriva una funzione o programma che determina la distanza tra due nodi k1 e k2 nella rete. (5p)
aiuto:
- salva gli id dei nodi nel percorso dalla radice a ciascuno dei due nodi separatamente
- poi determina l'id comune più a destra nelle liste salvate (ovvero i percorsi)
- somma le distanze dalla fine dei due array rispetto a questo id

punti massimi = 16.5. ogni punto corrisponde ad un voto
'''

class Device():
    def __init__(self, k) -> None:
        self.k = k 
        self.left = None
        self.right = None
        
    # aggiungo un nuovo device alla rete 
    def insert(self, k):
        # ho una chiave minore
        if k < self.k:
            # se c'è un figlio destro proseguo
            if self.left: 
                self.left.insert(k)
            # se non c'è, inserisco
            else:
                self.left = Device(k)
        # stessa cosa ma a destra
        else:
            if self.right:
                self.right.insert(k)
            else: 
                self.right = Device(k)
                
    # questa funzione permette di stampare in ordine i dispositivi dall'id minore al maggiore
    def inorder(self):
        if self.left:
            self.left.inorder()
        print(self.k)
        if self.right: 
            self.right.inorder()
            


# numero casuale con la virgola = random.uniform(n,m)
# crea un grafico: plt.plot(x,y)
# visualizza un grafico: plt.show()
