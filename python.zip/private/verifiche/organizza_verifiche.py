import os
import shutil
import os
import shutil

def trova_e_copia_file_python(root_dir, nome_sottocartella, destinazione):
    # Crea la cartella di destinazione se non esiste
    if not os.path.exists(destinazione):
        os.makedirs(destinazione)

    # Scansiona tutte le directory a partire da root_dir
    for cartella_corrente, sottocartelle, files in os.walk(root_dir):
        # Se la sottocartella desiderata è presente
        if nome_sottocartella in sottocartelle:
            percorso_sorgente = os.path.join(cartella_corrente, nome_sottocartella)

            # Cerca tutti i file .py all'interno della sottocartella e delle eventuali sottocartelle innestate
            for root, _, files_in_dir in os.walk(percorso_sorgente):
                for file in files_in_dir:
                    if file.endswith(".py"):
                        percorso_file = os.path.join(root, file)
                        destinazione_file = os.path.join(destinazione, os.path.relpath(percorso_file, percorso_sorgente))

                        # Crea la struttura di cartelle nella destinazione se non esiste
                        os.makedirs(os.path.dirname(destinazione_file), exist_ok=True)

                        # Copia il file nella destinazione
                        shutil.copy2(percorso_file, destinazione_file)
                        print(f"Copiato {percorso_file} in {destinazione_file}")

# Esempio di utilizzo
root_dir = "F:\\INSEGNAMENTO - BACKUP\\verifiche"
nome_sottocartella = "esercitazione in classe 30-09-2024"
cartella_destinazione = "F:\\INSEGNAMENTO - BACKUP\\archivio_verifiche"

trova_e_copia_file_python(root_dir, nome_sottocartella, cartella_destinazione)