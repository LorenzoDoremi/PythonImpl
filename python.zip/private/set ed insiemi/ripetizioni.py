def ripetizioni(array):
    
    repetitions = set()
    found_elements = set()
    for i in array:
        if i in found_elements:
         repetitions.add(i)
        else:
         found_elements.add(i)
    return repetitions





a = [0,1,2,3,2,6,7,1,2,2,2,3,8,2]

rep = ripetizioni(a)
print(rep)