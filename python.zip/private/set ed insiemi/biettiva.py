from re import T
import time


def biettiva(f, n, n2):
    surr = False
    ini = True
   

    solutions = set()
    for i in n:
        solutions.add(f(i))
    
    ''' if len(n2) == len(solutions.intersection(n2)):
        surr = True '''
    # se tutte le soluzioni che posso generare sono un superset di quelle cercate, allora sicuramente è suriettiva
    if solutions.issuperset(n2):
        surr = True
    

    # per ogni valore in N, salvo il risultato f(n) se lo trovo una volta in N2. se lo trovo una seconda volta, allora non è iniettiva
    vis = set()
    for i in n:
        if f(i) in n2 and f(i) not in vis:
            vis.add(f(i))
        elif f(i) in n2 and f(i) in vis:
            ini = False
            break
    
    return (surr, ini, surr and ini)



n = set([0, 1, 2])
n2 = set([0,1,4])

t = time.time()*1000
for i in range(0,10000):
 s, i , b = biettiva(lambda x : x**2, n,n2)

t2 = time.time()*1000 - t
print(t2)

print(s)
print(i)
print(b)
