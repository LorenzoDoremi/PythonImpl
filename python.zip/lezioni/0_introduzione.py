
# impariamo le variabili e le operazioni di base. 

x = 5
print(x)

x = 10
print(x)

x = x+2 #  x+=2
print(x)

x = x*3 # x*=3
print(x)

x %= 4
print(x)

x = x**5
print(x)

parola = "ciao!"
print(parola)
# il casting. ovvero convertire un tipo in un altro a noi più comodo

x = 6.345

x_intero = int(x) # 6
x_parola = str(x)
print(x_intero)



# SHIFT + ALT + F = indenta il codice per noi