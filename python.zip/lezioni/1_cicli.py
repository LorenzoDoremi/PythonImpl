#impariamo ad eseguire operazioni tante volte: i loop o cicli
for i in range(0,10):
    print(i, end="-")

print("")


for k in range(0,20,2):
      print(k, end="-")

print("")


for x in range(5):
      print(x, end="-")
print("")




j = 0
while(j < 10):
    print(j, end="-")
    j+=1


