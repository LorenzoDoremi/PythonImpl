# git init -> creo un repository
# git add .  -> aggiungo tutti i file
# git commit -m "nuovo commit" -> salvo i file
# creo un repository su github e seguo istruzioni
# git branch "nome branch" -> creo una nuova branch (in cui fare modifiche pazze :D)
# git checkout "nome branc" -> per cambiare branch