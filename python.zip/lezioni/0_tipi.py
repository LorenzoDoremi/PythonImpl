from numpy import ceil
from numpy import floor 

a = 4.45
print(ceil(a))
print(round(a))
print(floor(a))

b = int(a)
c = a == b 
print(c)


