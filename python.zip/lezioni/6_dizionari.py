utente =  {"nome": "Lorenzo", "anni": 30}

#stampo 30
anni = utente["anni"]
print(anni)

# aumento l'età
utente["anni"] += 2 

# stamperà 32
print(utente["anni"])



