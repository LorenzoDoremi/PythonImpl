from example import randimporter


print(randimporter())