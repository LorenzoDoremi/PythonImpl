

from numpy import mean
#test importazione

print("grazie per aver importato questa libreria!")
def randimporter():
    return 0
